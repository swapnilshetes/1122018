package com.indecomm.automation;

public class constant {
	public static final String FILE_MOBILE_DATA = "/feedFiles/automationMobileData.json";
	public static final String FILE_LOCATOR = "/feedFiles/locator.properties";
}
