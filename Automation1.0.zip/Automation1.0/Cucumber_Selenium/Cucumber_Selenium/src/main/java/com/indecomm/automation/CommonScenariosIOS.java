package com.indecomm.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.indecomm.fixtures.AbstractAutomationFixtures;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CommonScenariosIOS {

	private AppiumDriver driver;
	AbstractAutomationFixtures abstractAutomationFixtures;
	ElementRepository elementRepository;
	String propetyPath;

	public CommonScenariosIOS(AppiumDriver<MobileElement> driver) {
		this.driver = driver;
		System.out.println(":: Start redirecting on login page ::");
		propetyPath = System.getProperty("user.dir") + "/" + "/feedFiles/locator.properties";

		elementRepository = new ElementRepository(propetyPath);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public void AppLoginIOS(String platform) throws InterruptedException {

		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 15); WebElement continueButton
		 * = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated((MobileBy.xpath(elementRepository.
		 * getPropertyByTag("continueBtn"))))); continueButton.click();
		 * Thread.sleep(4000);
		 */

		Thread.sleep(6000);
		WebElement el11 = this.driver.findElementById(elementRepository.getPropertyByTag("continueBtn"));
		el11.click();

		Thread.sleep(6000);
		WebElement el2 = this.driver.findElementById(elementRepository.getPropertyByTag("userNameFld"));
		el2.click();
		Thread.sleep(6000);

		el2.sendKeys("automation@test.com");
		Thread.sleep(3000);

		WebElement el3 = this.driver.findElementById(elementRepository.getPropertyByTag("passwordFld"));
		el3.click();

		el3.sendKeys("Test123-");
		Thread.sleep(6000);

		WebElement el4 = this.driver.findElementById(elementRepository.getPropertyByTag("loginBtn"));
		el4.click();
		Thread.sleep(5000);

		// WebElement el5 =
		// this.driver.findElementByXPath("//*[@class='android.view.View'] and
		// contains((text(),'APPLIANCES')");
		// this.driver.wait(10).until(ExpectedConditions.presenceOfElementLocated(By.linkText("Appliances")));
		new WebDriverWait(driver, 10).until(
				ExpectedConditions.presenceOfElementLocated(By.id(elementRepository.getPropertyByTag("applianceTab"))));

		WebElement el5 = this.driver.findElementById(elementRepository.getPropertyByTag("applianceTab"));
		el5.click();
		Thread.sleep(5000);

//		WebElement el6 =  this.driver.findElementByXPath("//*[@class='android.view.View' and contains(text(),'MY WASHER')]");
//		el6.click();
//		Thread.sleep(3000);

		/*
		 * Click on Continue button to redirect loginpage
		 */
		/*
		 * Thread.sleep(5000); if(btnContinue.isDisplayed())
		 * System.out.println("btnContinue.-----------------------");
		 * 
		 * //abstractAutomationFixtures.waitForPageToLoad(driver, btnContinue, 10);
		 * btnContinue.click();
		 */

		// Wait until find Element

		// abstractAutomationFixtures.waitForElement(driver, btnLogin, 10);

		/*
		 * On Login page to enter credential
		 */

		// abstractAutomationFixtures.sendText(txtUserName,
		// "devemerald@electrolux.com");
		//// abstractAutomationFixtures.sendText(txtPassword, "Bhasha23@");
		// abstractAutomationFixtures.click(btnLogin);
	}

}
