package com.indecomm.dto;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;

import com.indecomm.data.XLSProcessor;
import com.indecomm.util.AutomationUtility;

public class AutomationDTO {

	JSONObject jsonObject;
	XLSProcessor objXLS;

	public JSONObject getDataJson(String fileName) {

		jsonObject = AutomationUtility.readJSON(fileName);
		return jsonObject;
	}

	public XSSFWorkbook getDataExcel(String fileName) {

		objXLS = new XLSProcessor();
		objXLS.processData(fileName);
		System.out.println("innnnnnnnnnnn-------------" + objXLS.getData());
		return (XSSFWorkbook) objXLS.getData();

	}

}
