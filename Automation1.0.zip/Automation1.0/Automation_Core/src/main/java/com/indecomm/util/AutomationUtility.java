package com.indecomm.util;
//Coarse grained Utility class.
import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.indecomm.context.Configuration;
import com.indecomm.dto.CustomDesiredCapabilities;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class AutomationUtility {

	
	public static JSONObject readJSON(String fileName)
	{
		JSONParser parser=new JSONParser();
		JSONObject jsonObject=null;
		try
		{
		String cwd = System.getProperty("user.dir") + fileName;
		Object obj = parser.parse(new FileReader(cwd));
		jsonObject = (JSONObject) obj;
		}catch(Exception exc)
		{
			System.out.println("Reading JSON ===>>>"+exc.getMessage());
		}
		return jsonObject;
	}
	
	public static CustomDesiredCapabilities getDesiredCapabilities(JSONObject jsonObject,String platform)
	{
		DesiredCapabilities desiredCapabilities=null;
		CustomDesiredCapabilities cDesiredCapabilities=new CustomDesiredCapabilities();
		
		JSONObject jsonObj=(JSONObject)jsonObject.get(platform);
		
		if(platform.contains(Configuration.ANDROID_DEVICE))
		{
			desiredCapabilities=DesiredCapabilities.android();
		//	desiredCapabilities.setVersion("1.9.1");
			if(Configuration.LOG_FLAG) System.out.println(":: JSON is  Android Logs :: "+jsonObj.toJSONString());
			
			desiredCapabilities.setCapability(Configuration.APP,(String)(((JSONObject)jsonObj.get("capabilities")).get("app")));
			desiredCapabilities.setCapability(Configuration.PLATFORM_NAME,(String)(((JSONObject)jsonObj.get("capabilities")).get("platformName")));
			desiredCapabilities.setCapability(Configuration.PLATFORM_VERSION,(String)(((JSONObject)jsonObj.get("capabilities")).get("platformVersion")));
			desiredCapabilities.setCapability(Configuration.DERICE_NAME, (String)(((JSONObject)jsonObj.get("capabilities")).get("device")));
			desiredCapabilities.setCapability(Configuration.APPWAITACTIVITY,(String)(((JSONObject)jsonObj.get("capabilities")).get("appWaitActivity")));
			desiredCapabilities.setCapability(Configuration.UDID,(String)(((JSONObject)jsonObj.get("capabilities")).get("udid")));
			desiredCapabilities.setCapability(Configuration.AUTO_GRANT_PERMISSION,true);
			desiredCapabilities.setCapability(Configuration.AUTO_ACCEPT_ALERT, true);
			
		
		}
		else if(platform.contains(Configuration.IOS_DEVICE))
		{
			desiredCapabilities=new DesiredCapabilities();
			if(Configuration.LOG_FLAG) System.out.println(":: JSON is iOS Logs::" + jsonObj.toJSONString());
			desiredCapabilities.setCapability(Configuration.UDID,(String)(((JSONObject)jsonObj.get("capabilities")).get("deviceudid")));
			desiredCapabilities.setCapability(Configuration.APP,(String)(((JSONObject)jsonObj.get("capabilities")).get("app")));
			desiredCapabilities.setCapability(Configuration.PLATFORM_NAME,(String)(((JSONObject)jsonObj.get("capabilities")).get("platformName")));
			desiredCapabilities.setCapability(Configuration.AUTO_ACCEPT_ALERT, true);
			desiredCapabilities.setCapability(Configuration.PLATFORM_VERSION,(String)(((JSONObject)jsonObj.get("capabilities")).get("platformVersion")));
			desiredCapabilities.setCapability(Configuration.DERICE_NAME, (String)(((JSONObject)jsonObj.get("capabilities")).get("device")));	
			desiredCapabilities.setCapability(Configuration.IOS_AUTOMATON_NAME, (String)(((JSONObject)jsonObj.get("capabilities")).get("automationName")));
			desiredCapabilities.setCapability(Configuration.IOS_BUNDLEID, (String)(((JSONObject)jsonObj.get("capabilities")).get("bundleid")));
			desiredCapabilities.setCapability(MobileCapabilityType.NO_RESET, (String)(((JSONObject)jsonObj.get("capabilities")).get("reset")));
			
		}
		cDesiredCapabilities.setDesiredCapabilities(desiredCapabilities);
		cDesiredCapabilities.setAppiumServer((String)(((JSONObject)jsonObj.get("capabilities")).get("appiumServer")));
		cDesiredCapabilities.setPort((String)(((JSONObject)jsonObj.get("capabilities")).get("port")));
		return cDesiredCapabilities;
		
	}
	


}
