package com.indecomm.context;

public class Configuration {
	
	public static final String ANDROID_DEVICE = "Android";
	public static final String IOS_DEVICE = "iOS";
	public static final String DEVICE_CONTEXT = "WEBVIEW_com.elux.electroluxlife";
	
	public static final boolean  LOG_FLAG = true;
	
	/*
	 * Common Capabilities
	 * */
	
	public static final String APP = "app";
	public static final String PLATFORM_NAME = "platformName";
	public static final String PLATFORM_VERSION = "platformVersion";
	public static final String DERICE_NAME = "deviceName";
	public static final String APPWAITACTIVITY = "appWaitActivity";
	public static final String UDID = "udid";
	public static final String AUTO_GRANT_PERMISSION = "autoGrantPermissions";
	public static final String AUTO_ACCEPT_ALERT = "autoAcceptAlerts";
	
	public static final String IOS_AUTOMATON_NAME = "automationName";
	public static final String IOS_BUNDLEID = "bundleid";
}
